/**
 * Created by Hermit on 16/8/27.
 */
var delete_strategy_list;
var strategy_list;

var stockList;
var strategy_list_data;

function initStrategyListPage() {
    stockList = parent.stockList;

    $.ajax({
        type: "get",
        url: http_path+strategy_list_desktop_path,
        dataType: "json",
        success: function(data) {
            strategy_list_data = data.strategy_list;
            initHtmlData(data.strategy_list);
        },
        error: function() {
            console.log("strategy list error");
        }
    });
}

function initHtmlData(data) {
    $(".strategy-list").html("");

    var i;
    for(i=0;i<data.length;i++){
        var strategy = data[i];

        var stateString = "";

        if(strategy.isJson==1){
            stateString = "<span class='column-item'>流程图</span>"
        }else{
            stateString = "<span class='column-item'>代码</span>"
        }

        $(".strategy-list").append("" +
            "<div class='column strategy-item'>" +
            "   <span class='column-item u1of10 delete-strategy'><i class='fa fa-close'></i></span>" +
            "   <div class='column-item strategy-info column'>" +
            "       <span class='column-item strategy-name'>"+strategy.strategyname+"</span>" +
            "       <span class='column-item'>"+strategy.updateAt+"</span>" +
            "       " + stateString +
            "</div>" +
            "</div>");
    }

    delete_strategy_list = document.querySelectorAll(".delete-strategy");
    strategy_list = document.querySelectorAll(".strategy-item .strategy-info");

    initButtonListener();
}

function initButtonListener() {
    $(".strategy-list .delete-strategy").on("click", function() {
        var index = -1;
        for(var i=0;i<delete_strategy_list.length;i++){
            if(this==delete_strategy_list[i]){
                index = i;
                break;
            }
        }
        console.log(index);
        var strategy_id = strategy_list_data[index].strategyid;
        $.ajax({
            type: "get",
            url: "user/strategy/delete-strategy.do?strategy_id="+strategy_id,
            dataType: "json",
            success: function(data) {
                console.log(data);
                if(data.success==true){
                    window.location.reload();
                }else{
                    parent.alert("删除失败,请稍后再试");
                }
            },
            error: function() {
                parent.alert("删除失败,请稍后再试");
            }
        });
    });
    $(".strategy-item .strategy-info").bind("click", function(e) {
        var index = -1;
        for(var i=0;i<strategy_list.length;i++){
            if(this==strategy_list[i]){
                index = i;
                break;
            }
        }
        console.log(index);
        parent.nextStrategy = strategy_list_data[index].strategyid;
        parent.isNew = false;

        window.location.href = "../../html/workspace/strategy-editor.html";
    });
    $("#add_new_strategy").on("click", function() {
        parent.isNew = true;
        window.location.href = "../../html/workspace/strategy-editor.html";
    });
}

window.onload = function() {
    initStrategyListPage();
};
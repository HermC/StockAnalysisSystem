/**
 *
 * 界面数据的获取以及更新
 *
 * */
var stockList;

function initRecommandAllPage() {
    if(parent.recommandall_data==null){
        $.ajax({
            type: 'GET',
            url: http_path+recommandall_desktop_path,
            dataType: 'json',
            success: function(data) {
                stockList = data.stockList;
                initHtmlData(data);

                parent.recommandall_data = data;
            },
            error: function() {
                console.log("error");
            }
        });
    }else{
        var data = parent.recommandall_data;
        stockList = data.stockList;
        initHtmlData(data);
    }
}

function initHtmlData(data) {
    var kdj = data.kdj;
    var rsi = data.rsi;
    var boll = data.boll;

    var i;
    for(i=0;i<kdj.length;i++){
        var kdjS = kdj[i];
        $("#desktop-kdj").append(""+
            "<a onclick='toSelectStock(\""+kdjS.id+"\")'><h5><p>"+kdjS.name+"</p> <span>"+kdjS.id+"</span></h5></a>");
    }
    for(i=0;i<rsi.length;i++){
        var rsiS = rsi[i];
        $("#desktop-rsi").append(""+
            "<a onclick='toSelectStock(\""+rsiS.id+"\")'><h5><p>"+rsiS.name+"</p> <span>"+rsiS.id+"</span></h5></a>");
    }
    for(i=0;i<boll.length;i++){
        var bollS = boll[i];
        $("#desktop-boll").append(""+
            "<a onclick='toSelectStock(\""+bollS.id+"\")'><h5><p>"+bollS.name+"</p> <span>"+bollS.id+"</span></h5></a>");
    }
}

// function toSelectStock(stockid) {
//     $.ajax({
//         type: 'GET',
//         url: http_path+stock_request+stockid,
//         success: function (data) {
//
//         },
//         error: function () {
//             console.log("error");
//         }
//     });
//
//     window.open(stock_desktop_local, '_self', '');
// }

window.onload = function() {
    initRecommandAllPage();
};
/**
 * 导航栏用
 * */
var pages = ["../../html/presentation/index.html",
    "../../html/presentation/industry.html",
    "../../html/presentation/stockcompare.html",
    // "../../html/presentation/recommand.html",
    "../../html/workspace/stockpool.html",
    "../../html/workspace/strategy-list.html",
    "../../html/workspace/simulator-transaction.html",
    "../../html/workspace/association-list.html",
    "../../html/workspace/forum.html"];
var preActiveNav = null;

var userNavList;

function initialNav() {
    $.ajax({
        type: "get",
        url: http_path+user_info_path,
        dataType: "json",
        success: function(data) {
            if(data.success==false){
                return;
            }
            var userInfo = data.userInfo;
            console.log(userInfo);
            $("#user-name").html(userInfo.UserName);

            if(userInfo.Head!=null){
                changeImg(userInfo.Head);
            }
        },
        error: function() {
            console.log("user info error");
        }
    });

    userNavList = document.querySelectorAll(".main-nav-item");
    preActiveNav = userNavList[0];
    $(preActiveNav).addClass("main-nav-item-selected");

    $(".main-nav-container").on("click", ".main-nav-item", function() {
        var index = 0;
        for(var i = 0;i < userNavList.length;i++){
            if(this == userNavList[i]){
                index = i;
                break;
            }
        }
        console.log(index);
        $(preActiveNav).removeClass("main-nav-item-selected");
        preActiveNav = this;
        $(this).addClass("main-nav-item-selected");
        $("#main-page").attr("src", pages[index]);
    });

    $.ajax({
        type: 'get',
        url: http_path+user_nav_search_path,
        dataType: 'json',
        success: function(data) {
            stockList = data["stockList"];
        },
        error: function() {
            console.log("nav error");
        }
    });

    $("body").bind("click", function(e) {
        if(e.target!=document.getElementById("nav_search_result")){
            $("#nav_search_result").hide();
        }
    });

    $("#nav_search_input").bind("input propertychange",function(){
        $("#nav_search_result").show();
        var searchContent = $(this).val();
        searchNav(searchContent);
    });
}

function searchNav(search){
    var searchResult = "";
    var resultNum = 0;
    var tempId;
    var tempName;
    for(var i = 0;i < stockList.length && resultNum < 10;i++){
        tempId = stockList[i].id+"";
        tempName = stockList[i].name+"";
        if(tempId.indexOf(search) != -1 || tempName.indexOf(search) != -1){
            searchResult +='<a class="nav-search-item"><span>'+tempName+'</span>&nbsp;&nbsp;&nbsp;<span class="nav-search-id">'+tempId+'</span></a>';
            resultNum ++;
        }
    }
    $("#nav_search_result").html(searchResult);
    $("#nav_search_result").on("click", ".nav-search-id", function() {
        navToSelectStock($(this).html());
    })
}

function changeImg(url) {
    $(".user-head-img").attr("src", url);
}

window.onload = function() {
    initialNav();
};
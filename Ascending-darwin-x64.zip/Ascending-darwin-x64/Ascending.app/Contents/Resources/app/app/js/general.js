/**
 *
 * 全局路径
 *
 * */
// var http_path = "http://localhost:8888/Dracarys/";
var http_path = "http://www.anyquant.net:40002/";
var index_desktop_path = "index_desktop.do";
var industry_desktop_path = "industry_desktop.do";
var compare_desktop_path = "compare_desktop.do";
var recommand_desktop_path = "recommand_desktop.do";
var recommandall_desktop_path = "recommandall_desktop.do";

var stock_desktop_local = "../../html/presentation/stocksingle.html";
var stock_desktop_path = "stock_desktop.do?id=";

var user_info_path = "user_desktop.do";
var user_nav_search_path = "user/nav.do";

var stockpool_desktop_path = "user/stockpool_desktop.do";
var strategy_list_desktop_path = "user/strategy_list_desktop.do";
var strategy_editor_desktop_path = "user/strategy_editor_desktop.do";
var simulator_list_desktop_path = "user/simulator_list_desktop.do";
var simulator_info_desktop_path = "user/simulator_info_desktop.do";
var association_list_desktop_path = "user/association_desktop.do";
var forum_list_desktop_path = "user/forum/search_desktop.do";
var forum_card_desktop_path = "user/forum_card_desktop.do";

var head_picture_path = "resources/img/user/default.jpg";

/**
 *
 * 保存变量
 *
 * */
var nextStock = "sh600000";
var nextStrategy = "";
var isNew = true;
var nextSimulator = "";
var nextTopic = "";

var index_data = null;
var recommand_data = null;
var recommandall_data = null;
var industry_data = null;

var stockList;

function toSelectStock(stockid) {
    parent.nextStock = stockid;

    var userNavList = parent.document.querySelectorAll(".main-nav-item");
    $(parent.preActiveNav).removeClass("main-nav-active");
    $(userNavList[1]).addClass("main-nav-active");
    parent.preActiveNav = userNavList[1];

    window.open(stock_desktop_local, '_self', '');
}

function navToSelectStock(stockid) {
    console.log(stockid);
    parent.nextStock = stockid;

    $("#main-page").attr("src", stock_desktop_local);
}
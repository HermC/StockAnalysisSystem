/**
 *
 * 界面数据的获取与更新
 *
 * */
var stockList;
var intraday;

function initIndexPage() {
    if(parent.index_data==null){
        $.ajax({
            type: "GET",
            url: http_path+index_desktop_path,
            dataType: "json",
            success: function(data) {
                stockList = data.stockList;
                intraday = data.intraday;
                initHtmlData(data);
                initCharts();

                parent.index_data = data;
            },
            error: function() {
                console.log("error");
            }
        });
    }else{
        var data = parent.index_data;
        stockList = data.stockList;
        intraday = data.intraday;
        initHtmlData(data);
        initCharts();
    }
}

function initHtmlData(data) {
    var stockRank = data.stockRank;
    var industryRank = data.industryRank;
    var stopRecommend = data.stopRecommend;
    var hotspots = data.hotspots;
    var financeNews = data.financeNews;
    var stockNews = data.stockNews;
    var companyNews = data.companyNews;

    var i;
    for(i=0;i<stockRank.length;i++){
        var stock = stockRank[i];
        $('#desktop-stockRank').append(""+
            "<tr><td>"+(i+1)+"</td><td>"+stock.stockname+"</td><td>"+stock.price+"</td><td>"+stock.deviation+"%</td><td>"+stock.turnover+"</td></tr>");
    }
    for(i=0;i<industryRank.length;i++){
        var industry = industryRank[i];
        $('#desktop-industryRank').append(""+
            "<tr><td>"+(i+1)+"</td><td>"+industry.industryname+"</td><td>"+industry.industrydevia+"</td><td>"+industry.stockname+"</td><td>"+industry.stockdevia+"</td></tr>");
    }
    for(i=0;i<stopRecommend.length;i++){
        var stop = stopRecommend[i];
        $('#stop_recommend').append(""+
            "<tr class='stop_recommand_stock'>" +
            "   <td><a onclick='toSelectStock(\""+stop.id+"\")'>"+stop.name+"</a></td>" +
            "   <td><a onclick='toSelectStock(\""+stop.id+"\")'>"+stop.id+"</a></td>" +
            "</tr>");
    }
    for(i=0;i<hotspots.length;i++){
        var hotspot = hotspots[i];
        $('#desktop-hotspots').append(""+
            "<div class='hot_item'>" +
            "   <a href='"+hotspot.url+"' target='_blank'>" +
            "       <div class='hot_item_title'>" +
            "           <h1>"+hotspot.keyword+"</h1>" +
            "           <h2>"+hotspot.date+"</h2>" +
            "           <h2>"+hotspot.description+"</h2>" +
            "       </div>" +
            "   </a>" +
            "   <a href='"+hotspot.url+"' target='_blank'>" +
            "       <div class='hot_item_ds'>" +
            "           "+hotspot.drivingEvent+"" +
            "       </div>" +
            "   </a>" +
            "   <div class='hot_item_stocks'>" +
            "       <div class='hot_item_stock'>" +
            "           <h1>"+hotspot.stockName1+"<span>"+hotspot.stockID1+"</span></h1>" +
            "           <h1 class='narrow'>"+hotspot.stockPrice1+"</h1>" +
            "           <h1 class='narrow'>"+hotspot.devia1+"</h1>" +
            "       </div>" +
            "       <div class='hot_item_stock'>" +
            "           <h1>"+hotspot.stockName2+" <span>"+hotspot.stockID2+"</span></h1>" +
            "           <h1 class='narrow'>"+hotspot.stockPrice2+"</h1>" +
            "           <h1 class='narrow'>"+hotspot.devia2+"</h1>" +
            "       </div>" +
            "       <div class='hot_item_stock'>" +
            "           <h1>"+hotspot.stockName3+" <span>"+hotspot.stockID3+"</span></h1>" +
            "           <h1 class='narrow'>"+hotspot.stockPrice3+"</h1>" +
            "           <h1 class='narrow'>"+hotspot.devia3+"</h1>" +
            "       </div>" +
            "   </div>" +
            "</div>");
    }
    for(i=0;i<financeNews.length;i++){
        var finance = financeNews[i];
        $('#desktop-financeNews').append(""+
            "<a href='"+finance.url+"' target='_blank'>"+finance.title+"</a>");
    }
    for(i=0;i<stockNews.length;i++){
        var stock = stockNews[i];
        $('#desktop-stockNews').append(""+
            "<a href='"+stock.url+"' target='_blank'>"+stock.title+"</a>");
    }
    for(i=0;i<companyNews.length;i++){
        var company = financeNews[i];
        $('#desktop-companyNews').append(""+
            "<a href='"+company.url+"' target='_blank'>"+company.title+"</a>");
    }
}

// function toSelectStock(stockid) {
//     $.ajax({
//         type: 'GET',
//         url: http_path+stock_request+stockid,
//         success: function (data) {
//
//         },
//         error: function () {
//             console.log("error");
//         }
//     });
//
//     window.open(stock_desktop_local, '_self', '');
// }

/**
 *
 * 初始化其他部分
 *
 * */
window.onload = function() {
    initIndexPage();
    initialHeader();
    operationListener();
    showBenchLink();
};

function showBenchLink(){
    $('#bench_title ul').bind('mouseover',function(){
        $('#bench_dynamic_wrapper ul li.bench_link').each(function(){
            $(this).show();
        });
        $('.more_button').hide();
    }).bind('mouseleave',function(){
        $('#bench_dynamic_wrapper ul li.bench_link').each(function(){
            $(this).hide();
        });
        $('.more_button').show();
    });
}

function operationListener() {
    $(".operation").on("click", ".favor", function() {
        //operateFavStock(stock_id);
        operationNotice($(this.parentNode), "收藏成功!");
    });
    $(".operation").on("click", ".add", function() {
        //addCompareStock(stock_id);
        operationNotice($(this.parentNode), "添加对比成功!");
    });
}

function operationNotice(node, text){
    $(node.find("p")).html(text);
    $(node.children(".favor")).hide();
    $(node.children(".add")).hide();
    $(node.children(".operation_alert")).slideDown();
    setTimeout(function(){
        $(node.children(".operation_alert")).hide();
        $(node.children(".favor")).show();
        $(node.children(".add")).show();
    },800);
}

function addCompareStock(id) {

    var tmp = $.cookie('compareStock');

    var result;

    if(tmp!=undefined){
        var result = tmp.split(",");
        if(result[0]=="null"){
            result.shift();
        }

        for(var i=0;i<result.length;i++){
            if(result[i]==id){
                return;
            }
        }

        result.push(id);

        //if(result.length>15){
        //    result.shift();
        //}

    }else{
        result = [id];
    }

    $.cookie('compareStock', result.join(','), {
        path: '/'
    });

    console.log($.cookie('compareStock'));
}

/**********************************
 *
 * 动态接口
 */


function requestDynamicData() {

    $.ajax({
        type: 'GET',
        url: http_path+"bench/active.do?id=399001",
        dataType: 'json',
        success: function(data) {
            console.log(data);
            updateDynamicData(data.data);
        },
        error: function() {
            //alert("current futureData error");
            console.log("error");
        }
    });
}

function updateDynamicData(data) {
    $("#dynamic_high").html(data.high);
    $("#dynamic_low").html(data.low);
    $("#dynamic_open").html(data.open);
    $("#dynamic_close").html(data.close);
    $("#dynamic_volume").html(data.volume);
    $("#dynamic_amount").html(data.amount);
    $("#dynamic_up_num").html(data.up_num);
    $("#dynamic_down_num").html(data.down_num);
    $("#dynamic_neutral_num").html(data.neutral_num);
}

window.setInterval(requestDynamicData, 5000);

/***********************
 *
 * 以下是图表
 * */

var intradayChart;

function initCharts() {
    AmCharts.theme = AmCharts.themes.dark;
    initDynamicData();
    initDynamicChart();
};

function initDynamicData() {
    for(var i=0;i<intraday.length;i++){
        var d = intraday[i].date+"";
        var t = intraday[i].time+"";
        if(t.length==8){
            t = "0"+t;
        }
        var tmp = AmCharts.stringToDate(""+d+t, "YYYYMMDDHHNNSSQQQ");
        intraday[i]["realTime"] = tmp;
    }
}

function initDynamicChart() {

    intradayChart = new AmCharts.AmStockChart();

    var categoryAxesSettings = new AmCharts.CategoryAxesSettings();
    categoryAxesSettings.minPeriod = "mm";
    categoryAxesSettings.color = "#cccccc";
    intradayChart.categoryAxesSettings = categoryAxesSettings;

    var dataSet = new AmCharts.DataSet();
    dataSet.fieldMappings = [{
        fromField: "price",
        toField: "value"
    }, {
        fromField: "volume",
        toField: "volume"
    }];
    dataSet.dataProvider = intraday;
    dataSet.categoryField = "realTime";

    intradayChart.dataSets = [dataSet];

    var timeSharePanel = new AmCharts.StockPanel();
    timeSharePanel.showCategoryAxis = false;
    timeSharePanel.title = "Value";
    timeSharePanel.percentHeight = 70;

    var valueAxis = new AmCharts.ValueAxis();
    valueAxis.color = "#cccccc";
    valueAxis.inside = true;
    timeSharePanel.addValueAxis(valueAxis);

    var valueGraph = new AmCharts.StockGraph();
    valueGraph.valueField = "value";
    valueGraph.valueAxis = valueAxis;
    valueGraph.type = "smoothedLine";
    valueGraph.lineThickness = 2;
    //valueGraph.bullet = "round";
    valueGraph.bulletSize = 4;
    valueGraph.bulletBorderColor = "#ffde00";
    valueGraph.bulletBorderAlpha = 1;
    valueGraph.bulletBorderThickness = 2;
    valueGraph.lineColor = "#ffde00";
    valueGraph.useDataSetColors = false;
    timeSharePanel.addStockGraph(valueGraph);

    var stockLegend1 = new AmCharts.StockLegend();
    stockLegend1.valueTextRegular = " ";
    stockLegend1.markerType = "none";
    timeSharePanel.stockLegend = stockLegend1;

    var volumePanel = new AmCharts.StockPanel();
    volumePanel.showCategoryAxis = true;
    volumePanel.title = "Volume";
    volumePanel.percentHeight = 30;

    var volumeAxis = new AmCharts.ValueAxis();
    volumeAxis.inside = true;
    volumeAxis.color = "#cccccc";
    volumePanel.addValueAxis(volumeAxis);

    var volumeGraph = new AmCharts.StockGraph();
    volumeGraph.valueField = "volume";
    volumeGraph.type = "column";
    //volumeGraph.cornerRadiusTop = 2;
    volumeGraph.fillAlphas = 1;
    volumeGraph.lineColor = "#ffde00";
    volumeGraph.fillColors = "#ffde00";
    volumeGraph.useDataSetColors = false;
    volumePanel.addStockGraph(volumeGraph);

    intradayChart.panels = [timeSharePanel, volumePanel];

    // OTHER SETTINGS ////////////////////////////////////
    var scrollbarSettings = new AmCharts.ChartScrollbarSettings();
    //scrollbarSettings.graph = valueGraph;
    scrollbarSettings.usePeriod = "10mm"; // this will improve performance
    scrollbarSettings.updateOnReleaseOnly = false;
    scrollbarSettings.position = "top";
    scrollbarSettings.color = "#cccccc";
    intradayChart.chartScrollbarSettings = scrollbarSettings;

    var cursorSettings = new AmCharts.ChartCursorSettings();
    cursorSettings.valueBalloonsEnabled = true;
    intradayChart.chartCursorSettings = cursorSettings;

    var panelsSettings = new AmCharts.PanelsSettings();
    panelsSettings.mouseWheelZoomEnabled = true;
    panelsSettings.usePrefixes = true;
    intradayChart.panelsSettings = panelsSettings;

    intradayChart.write('bench_graph_wrapper');
}
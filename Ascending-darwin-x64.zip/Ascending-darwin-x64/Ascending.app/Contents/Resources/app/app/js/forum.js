/**
 * Created by Hermit on 16/9/11.
 */

window.onload = function() {
    initButton();

    search("");
};

function initButton() {
    $("#up_forum").on("click", function() {
        //window.location.href = "user/forum-editor.do";
        // window.open("user/forum-editor.do");
        window.location.href = "../../html/workspace/forum-editor.html";
    });
    $("#search_button").on("click", function() {
        var keyword = $("#keyword").val();
        //searchLocal(keyword);
        console.log("jfisdf");
        search(keyword);
    });
}

function search(keyword) {
    $.ajax({
        type: "get",
        url: http_path+forum_list_desktop_path+"?keyword="+keyword,
        dataType: "json",
        success: function(data) {
            initHtmlData(data.topicList);
        },
        error: function() {
            console.log("搜索失败,请稍后再试");
        }
    });
}


var topicList;
var topic_list;
var topic_id;

function initHtmlData(data) {
    $("#forum_list").html("");

    topicList = data;

    var i;
    for(i=0;i<data.length;i++){
        var topic = data[i];

        $("#forum_list").append("" +
            "<div class='forum-list-item column'>" +
            "   <img class='user-head' src='"+http_path+head_picture_path+"'/>" +
            "   <div class='user-name column-item u1of4'>" +
            "       &nbsp;&nbsp;<span>"+topic.username+"</span>&nbsp;&nbsp;<span>("+topic.userid+")</span>" +
            "   </div>" +
            "   <span class='column-item forum-theme'>"+topic.title+"</span>" +
            "   <div class='user-click'>" +
            "       <span>回复:</span>&nbsp;&nbsp;<span class='reply'>"+topic.reply_count+"</span>" +
            "       &nbsp;&nbsp;" +
            "       <span>点击:</span>&nbsp;&nbsp;<span class='click'>"+topic.click_count+"</span>" +
            "   </div>" +
            "</div>");
    }

    topic_list = document.querySelectorAll(".forum-list-item");
    $(".forum-list-item").on("click", function() {
        var index = -1;
        for(var i=0;i<topic_list.length;i++){
            if(this==topic_list[i]){
                index = i;
                break;
            }
        }

        console.log(topicList[index]);
        topic_id = topicList[index].topicid;

        $.ajax({
            type: "get",
            url: http_path+"user/forum/update-click.do?topic_id="+topic_id,
            data: "json",
            success: function(data) {
                // window.open("user/forum-card.do?topic_id="+topic_id);
                parent.nextTopic = topic_id;

                window.location.href = "../../html/workspace/forum-card.html";
            },
            error: function() {
                alert("网络波动,请稍后");
            }
        });
    });

    var reply_list = document.querySelectorAll(".reply");
    var click_list = document.querySelectorAll(".click");
}

function searchLocal(keyword) {
    if(keyword==undefined||keyword==null||keyword==""){
        var nodes = $(".forum-theme").parent();
        $(nodes).show();
        return;
    }

    var nodes = document.querySelectorAll(".forum-theme");
    for(var i=0;i<nodes.length;i++){
        if($(nodes[i]).val().indexOf(keyword)>0){
            $($(nodes[i]).parent()).show();
        }else{
            $($(nodes[i]).parent()).hide();
        }
    }
}
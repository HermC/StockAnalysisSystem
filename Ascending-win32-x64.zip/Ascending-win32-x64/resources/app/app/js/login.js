/**
 * Created by Hermit on 2016/10/4.
 */

function login() {
    $(".login").on("click", function() {
        $(".header-wrapper").hide();
        $("#user_login_wrapper").show();
    });
    $("#login_register").on("click", function() {
        $("#login_form").hide();
        $("#register_form").show();
    });
    $("#register_back").on("click", function() {
        $("#register_form").hide();
        $("#login_form").show();
    });
    $("#user_login_wrapper").bind("click", function(e) {
        if(e.target == this){
            $(".header-wrapper").show();
            $(this).hide();
        }
    });
    $("#login_form input").bind("focus", function() {
        $("#error_user_info").html("");
        $("#error_password_info").html("");
    });
    $("#register_form input").bind("focus", function() {
        $("#repeat_username_info").html("");
        $("#different_password_info").html("");
        $("#register_failed").hide();
        $("#register_success").hide();
    });
    $("#login_submit").on("click", function() {
        var form = document.login_form;

        var username = form.username.value;
        var password = form.password.value;

        if(username==undefined||username==null||username==""){
            $("#error_user_info").html("用户名不能为空");
            return;
        }

        if(password==undefined||password==null||password==""){
            $("#error_password_info").html("密码不能为空");
            return;
        }

        $.ajax({
            type: "POST",
            url: http_path+"login.do",
            data: $("#login_form").serialize(),
            dataType: "json",
            beforeSend: function() {
                $("#login_submit").attr("disabled", true);
            },
            success: function(data) {
                console.log(data);
                if(data.success==true){
                    window.location.href = "../html/nav/usernav.html";
                }else{
                    if(data.state=="用户名不存在"){
                        $("#error_user_info").html(data.state);
                    }else{
                        $("#error_password_info").html(data.state);
                    }
                }
            },
            error: function() {

            },
            complete: function() {
                $("#login_submit").attr("disabled", false);
            }
        });
    });
    $("#register_submit").on("click", function() {
        var form = document.register_form;

        var nickname = form.nickname.value;
        var password = form.password.value;
        var confirm_password = form.confirm_password.value;

        if(nickname==undefined||nickname==null||nickname==""){
            $("#repeat_username_info").html("昵称不能为空");
            return;
        }

        if(password==undefined||password==null||password==""){
            $("#different_password_info").html("密码不能为空");
            return;
        }

        if(confirm_password!=password){
            $("#different_password_info").html("两次输入的密码不同");
            return;
        }

        $.ajax({
            type: "POST",
            url: http_path+"register.do",
            data: $("#register_form").serialize(),
            dataType: "json",
            beforeSend: function() {
                $("#register_submit").attr("disabled", true);
            },
            success: function(data) {
                if(data.success==true){
                    var userid = data.userid;
                    $("#register_userid").html(userid);
                    $("#register_wrapper").hide();
                    $("#register_success").show();
                }
            },
            error: function() {
                $("#register_failed").show();
                $("#register_submit").attr("disabled", false);
            },
            complete: function() {

            }
        });
    });
}
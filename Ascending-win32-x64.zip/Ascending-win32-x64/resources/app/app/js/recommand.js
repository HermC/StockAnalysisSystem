/**
 *
 * 界面数据的获取以及更新
 *
 * */
var stockList;

function initRecommandPage() {
    if(parent.recommand_data==null){
        $.ajax({
            type: 'GET',
            url: http_path+recommand_desktop_path,
            dataType: 'json',
            success: function(data) {
                stockList = data.stockList;
                initHtmlData(data);

                parent.recommand_data = data;
            },
            error: function() {
                console.log("error");
            }
        });
    }else{
        var data = parent.recommand_data;
        stockList = data.stockList;
        initHtmlData(data);
    }
}

function initHtmlData(data) {
    var stopList = data.stopList;
    var kdj = data.kdj;
    var rsi = data.rsi;
    var boll = data.boll;
    var grade = data.grade;

    var i;
    for(i=0;i<stopList.length;i++){
        var stopS = stopList[i];
        $("#desktop-recommand").append(""+
            "<a onclick='toSelectStock(\""+stopS.id+"\")'><h5><p>"+stopS.name+"</p> <span>"+stopS.id+"</span></h5></a>")
    }

    $("#desktop-recommand").append(""+
        "<br>" +
        "<br>" +
        "<a target='_self' href='../../html/presentation/recommandall.html'><h3>查看KDJ,RSI,BOLL所有推荐</h3></a>" +
        "<br>" +
        "<p class='stock_content_title'><img src='../../img/logo_s.png'>KDJ推荐</p>" +
        "<h6>K线由下往上穿过D线,有上涨趋势</h6>");

    for(i=0;i<kdj.length;i++){
        var kdjS = kdj[i];
        $("#desktop-recommand").append(""+
            "<a onclick='toSelectStock(\""+kdjS.id+"\")'><h5><p>"+kdjS.name+"</p> <span>"+kdjS.id+"</span></h5></a>");
    }

    $("#desktop-recommand").append(""+
        "<br>" +
        "<p class='stock_content_title'><img src='../../img/logo_s.png'>RSI推荐</p>" +
        "<h6>RSI处于高位,强买入</h6>");

    for(i=0;i<rsi.length;i++){
        var rsiS = rsi[i];
        $("#desktop-recommand").append(""+
            "<a onclick='toSelectStock(\""+rsiS.id+"\")'><h5><p>"+rsiS.name+"</p> <span>"+rsiS.id+"</span></h5></a>");
    }

    $("#desktop-recommand").append(""+
        "<br>" +
        "<p class='stock_content_title'><img src='../../img/logo_s.png'>BOLL推荐</p>" +
        "<h6>BOLL线开口变窄,价格高于中线,可能上涨</h6>");

    for(i=0;i<boll.length;i++){
        var bollS = boll[i];
        $("#desktop-recommand").append(""+
            "<a onclick='toSelectStock(\""+boll.id+"\")'><h5><p>"+bollS.name+"</p> <span>"+bollS.id+"</span></h5></a>");
    }

    for(i=0;i<grade.length;i++){
        var stock = grade[i];
        $("#stock_rank_total").append(""+
            "<tr onclick='toSelectStock(\""+stock.id+"\")'>" +
            "   <td>"+(i+1)+"</td>" +
            "   <td class='column_name_id'>"+stock.name+"<span>"+stock.id+"</span></td>" +
            "   <td>"+stock.score+"</td>" +
            "" +
            "   <td class='text_right'>"+stock.peAssess+"</td>" +
            "   <td class='text_right'>"+stock.pbAssess+"</td>" +
            "   <td class='text_right'>"+stock.updownAssess+"</td>" +
            "   <td class='text_right'>"+stock.volumeAssess+"</td>" +
            "   <td class='text_right'>"+stock.weibiAssess+"</td>" +
            "</tr>")
    }
}

/**
 *
 * 初始化图标等部分
 *
 * */
window.onload = function() {
    initRecommandPage();
    initialHeader();
};